package net.blueshadow.thorican.item;

import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public class ModCreativeModeTab {
    public static final CreativeModeTab THORICAN_TAB = new CreativeModeTab("thoricantab") {
        @Override
        public ItemStack makeIcon() {
            return new ItemStack(ModItems.THORICAN_INGOT.get());
        }
    };
}
